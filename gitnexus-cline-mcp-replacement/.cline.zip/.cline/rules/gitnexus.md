# GitNexus Non-MCP Rules for Cline

Use GitNexus through local CLI commands. Do not require MCP.

Before code-understanding, indexing, debugging, impact analysis, PR review, or refactoring tasks, choose the relevant GitNexus skill from `.cline/skills/`.

## Skill Routing

| Task | Read |
|---|---|
| Setup, index, reindex, status, list repos, doctor, clean index, wiki/docs | `.cline/skills/gitnexus-cli/SKILL.md` |
| Understand architecture or how code works | `.cline/skills/gitnexus-exploring/SKILL.md` |
| Debug errors/failures | `.cline/skills/gitnexus-debugging/SKILL.md` |
| Blast-radius / what breaks if code changes | `.cline/skills/gitnexus-impact-analysis/SKILL.md` |
| Rename, extract, split, move, refactor | `.cline/skills/gitnexus-refactoring/SKILL.md` |
| Review PRs or diffs | `.cline/skills/gitnexus-pr-review/SKILL.md` |
| API route, consumer, response-shape analysis | `.cline/skills/gitnexus-api-impact/SKILL.md` |
| Tool definitions/handlers in indexed repos | `.cline/skills/gitnexus-tool-map/SKILL.md` |
| Advanced graph queries | `.cline/skills/gitnexus-cypher/SKILL.md` |
| Multi-repo/group analysis | `.cline/skills/gitnexus-group/SKILL.md` |

## Default First Check

Run from the target repo root:

```bash
npx gitnexus status
```

If the repo is not indexed or the index is stale, run:

```bash
npx gitnexus analyze
```

## Command Rules

Prefer real CLI commands:

```bash
npx gitnexus list
npx gitnexus status
npx gitnexus analyze
npx gitnexus query "<concept>"
npx gitnexus context "<symbol>"
npx gitnexus impact "<symbol>" --direction upstream
npx gitnexus detect-changes --scope staged
```

Use universal non-MCP commands for MCP parity:

```bash
npx gitnexus call <tool> --json '{...}'
npx gitnexus read 'gitnexus://repo/<repo>/context'
```

Always read source files after GitNexus graph results before making final claims.
