---
name: gitnexus-exploring
description: Use when Cline needs to understand architecture, explore unfamiliar code, find where a concept lives, trace execution flows, inspect callers/callees, or answer how a feature/module/service works using GitNexus CLI without MCP.
---

# GitNexus: Exploring Codebases for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks how a feature, module, service, or flow works.
- The user asks where code for a concept lives.
- The user wants an architecture overview.
- The user asks who calls a symbol or what a symbol calls.
- The user is exploring an unfamiliar codebase.
- The user asks for execution flows, clusters/modules, or dependency relationships.

Example triggers:

- "How does authentication work?"
- "Explain the payment flow."
- "Where is user registration handled?"
- "What calls `validateUser`?"
- "Show me the main modules."

## First Check

Run from the target repository root:

```bash
npx gitnexus status
```

If GitNexus reports no index or stale index, run:

```bash
npx gitnexus analyze
```

If multiple repos are indexed, find the repo name:

```bash
npx gitnexus list
```

Later commands may need:

```bash
--repo <repo>
```

## Core Commands

```bash
# Search the knowledge graph for execution flows related to a concept
npx gitnexus query "<concept>" --repo <repo> --limit 5

# Improve ranking with task context and goal
npx gitnexus query "<concept>" --repo <repo> --context "<what you are doing>" --goal "<what you want to find>"

# Get 360-degree symbol context: callers, callees, processes, file location
npx gitnexus context "<symbol>" --repo <repo>

# Include full symbol source when useful
npx gitnexus context "<symbol>" --repo <repo> --content

# Disambiguate common symbols by file path
npx gitnexus context "<symbol>" --repo <repo> --file <path>
```

## MCP-Parity Resource Commands

Use these for repo/process/module navigation:

```bash
# Repo overview, stats, staleness, available tools
npx gitnexus read 'gitnexus://repo/<repo>/context'

# Functional areas / clusters
npx gitnexus read 'gitnexus://repo/<repo>/clusters'

# Details of one cluster/module
npx gitnexus read 'gitnexus://repo/<repo>/cluster/<clusterName>'

# All execution flows
npx gitnexus read 'gitnexus://repo/<repo>/processes'

# Step-by-step trace of one process
npx gitnexus read 'gitnexus://repo/<repo>/process/<processName>'
```

If resource output is insufficient, rely on `query`, `context`, and source-file inspection.

## Workflow: Understand How a Feature Works

1. Check index freshness:

   ```bash
   npx gitnexus status
   ```

2. If needed, list repos:

   ```bash
   npx gitnexus list
   ```

3. Search for the broad concept:

   ```bash
   npx gitnexus query "<feature or concept>" --repo <repo> --limit 5
   ```

4. Review returned processes, symbols, and file paths.
5. Pick 1-3 important symbols from the result.
6. Get context for each important symbol:

   ```bash
   npx gitnexus context "<symbol>" --repo <repo>
   ```

7. If a symbol is ambiguous, rerun with file path:

   ```bash
   npx gitnexus context "<symbol>" --repo <repo> --file <path>
   ```

8. Read the actual source files returned by GitNexus.
9. Answer with a concise architecture/flow summary and cite files/symbols.

## Workflow: Find What Calls a Symbol

1. Run:

   ```bash
   npx gitnexus context "<symbol>" --repo <repo>
   ```

2. Look for incoming references/callers.
3. If callers are too broad or ambiguous, use file disambiguation:

   ```bash
   npx gitnexus context "<symbol>" --repo <repo> --file <path>
   ```

4. Read caller files before making final claims.

## Workflow: Explore Main Modules

1. If available, read clusters:

   ```bash
   npx gitnexus read 'gitnexus://repo/<repo>/clusters'
   ```

2. If cluster resources are too broad or unavailable for the repo, query broad architecture terms:

   ```bash
   npx gitnexus query "main architecture modules services entry points" --repo <repo> --limit 10
   ```

3. Use `context` on representative symbols from each module.
4. Summarize modules by responsibility, key files, and entry points.

## How to Interpret Output

### `query` output

Focus on:

- Ranked processes/execution flows.
- Symbols grouped by process.
- File paths and line numbers.
- Definitions that appear outside process flows.

Use `query` results as a map, not final proof. Always inspect source files before final conclusions.

### `context` output

Focus on:

- Incoming calls: what depends on this symbol.
- Outgoing calls: what this symbol uses.
- Process participation: which execution flows include it.
- Disambiguation candidates if multiple symbols share a name.
- File path and symbol kind.

If `context` returns candidates instead of one exact result, choose the candidate matching the user's area/file and rerun with `--file` or `--uid` if supported.

## Decision Rules

- Use `query` for broad concepts: "auth", "payment", "onboarding".
- Use `context` for specific symbols: functions, classes, methods, handlers.
- Use `--content` only when source snippet is needed; otherwise prefer reading files directly.
- Use `--repo <repo>` when more than one indexed repo exists.
- Use `gitnexus read` resources for clusters/processes when useful.
- If GitNexus results are incomplete, supplement with grep/search and source reads.

## Output Guidance

When answering exploration questions, prefer this structure:

```markdown
Summary:
- One short explanation of how it works.

Key flow:
1. Entry point / handler
2. Main service/function
3. Dependencies/callees
4. Output/side effects

Important files:
- `path/file.ext` — why it matters

Notes / uncertainty:
- stale index, ambiguous symbols, dynamic references, or files not indexed
```

Keep the response practical. Do not dump raw GitNexus output unless the user asks.

## Safety Rules

- If `status` reports stale index, refresh before relying on graph results.
- Do not claim the graph is complete when parser warnings/skipped files exist.
- Dynamic calls, reflection, string-based routes, generated code, and dependency injection can be underrepresented in static analysis.
- Always read source files before making implementation recommendations.
- Do not run destructive commands in exploration workflows.

## Example: "How does authentication work?"

Run:

```bash
npx gitnexus status
npx gitnexus list
npx gitnexus query "authentication login session token validation" --repo <repo> --limit 5
npx gitnexus context "AuthService" --repo <repo>
```

Then read the key files returned by `query` and `context`.

Answer with:

- Main auth entry points.
- Validation/session/token flow.
- Important files/classes/functions.
- What calls what.
- Any uncertainty from stale/skipped/ambiguous results.

## Example: "What calls validateUser?"

Run:

```bash
npx gitnexus context "validateUser" --repo <repo>
```

If ambiguous:

```bash
npx gitnexus context "validateUser" --repo <repo> --file src/auth/validate.ts
```

Then inspect the returned caller files and summarize direct callers first.
