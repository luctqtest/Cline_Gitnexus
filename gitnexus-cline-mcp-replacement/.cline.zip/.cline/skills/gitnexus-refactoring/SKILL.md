---
name: gitnexus-refactoring
description: Use when Cline needs to safely rename, extract, split, move, or restructure code with GitNexus graph context, dry-run previews, impact analysis, and post-change verification without MCP.
---

# GitNexus: Refactoring for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks to rename a function/class/method/symbol.
- The user asks to extract code into a module/service.
- The user asks to split or move code safely.
- The user asks to refactor shared code and avoid breaking callers.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

## Commands

```bash
# Understand target symbol
npx gitnexus context "<symbol>" --repo <repo>

# Map callers/dependents before editing
npx gitnexus impact "<symbol>" --direction upstream --depth 3 --repo <repo>

# Find related flows/usages
npx gitnexus query "<symbol or concept>" --repo <repo> --limit 5

# Verify current edits after refactor
npx gitnexus detect-changes --scope all --repo <repo>
```

Rename via MCP-parity command:

```bash
# Always preview first
npx gitnexus call rename --json '{"symbol_name":"<old>","new_name":"<new>","dry_run":true,"repo":"<repo>"}'

# Apply only after reviewing preview
npx gitnexus call rename --json '{"symbol_name":"<old>","new_name":"<new>","dry_run":false,"repo":"<repo>"}'
```

If automated rename preview is insufficient, use GitNexus for analysis, then edit files manually with normal tools.

## Workflow: Rename Symbol

1. Check index.
2. Inspect symbol:

   ```bash
   npx gitnexus context "<old>" --repo <repo>
   ```

3. Check blast radius:

   ```bash
   npx gitnexus impact "<old>" --direction upstream --depth 3 --repo <repo>
   ```

4. If available, run rename dry-run.
5. Review every edit, especially low-confidence text matches.
6. Apply edits only after preview is acceptable.
7. Run:

   ```bash
   npx gitnexus detect-changes --scope all --repo <repo>
   ```

8. Run relevant tests/lint/build.

## Workflow: Extract / Split / Move

1. Run `context` on target.
2. Run upstream `impact` for external callers.
3. Run `query` for related flows.
4. Define new boundary/interface.
5. Edit implementation and imports.
6. Run `detect-changes`.
7. Run tests for affected flows.

## Safety Rules

- Never apply automated rename without dry-run review.
- Ask before destructive/broad refactors if scope is unclear.
- Public APIs should usually be versioned/deprecated, not silently broken.
- Low-confidence text/string/dynamic matches require manual source inspection.
- After refactor, verify with tests or at least typecheck/lint when available.

## Output Guidance

```markdown
Refactor plan:
- ...

Impact:
- direct callers / affected flows

Edits:
- files to change

Verification:
- detect-changes result
- tests/lint/build to run

Risks:
- dynamic refs / public API / stale index
```
