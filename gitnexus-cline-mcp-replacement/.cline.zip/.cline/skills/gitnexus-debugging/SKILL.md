---
name: gitnexus-debugging
description: Use when Cline needs to debug an error, trace a failing behavior, find where a symptom originates, inspect callers/callees of suspect code, or identify root cause using GitNexus CLI without MCP.
---

# GitNexus: Debugging for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks why something fails.
- The user provides an error message or stack trace.
- The user asks where an error comes from.
- The user reports unexpected behavior and needs root-cause analysis.
- Recent edits may have broken a flow.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

If multiple repos are indexed:

```bash
npx gitnexus list
```

## Commands

```bash
# Search graph for error text, symptom, or feature area
npx gitnexus query "<error text or symptom>" --repo <repo> --limit 5

# Inspect suspect symbol callers/callees/processes
npx gitnexus context "<suspectSymbol>" --repo <repo>
npx gitnexus context "<suspectSymbol>" --repo <repo> --content

# Analyze current local changes if regression may be local
npx gitnexus detect-changes --scope all --repo <repo>
npx gitnexus detect-changes --scope staged --repo <repo>

# Advanced custom graph tracing
npx gitnexus cypher '<read-only cypher query>' --repo <repo>
```

Resource commands:

```bash
npx gitnexus read 'gitnexus://repo/<repo>/processes'
npx gitnexus read 'gitnexus://repo/<repo>/process/<processName>'
npx gitnexus read 'gitnexus://repo/<repo>/schema'
```

## Workflow

1. Capture the symptom: error text, failing route, failing command, wrong output, or stack frame.
2. Check index status.
3. Search for the symptom:

   ```bash
   npx gitnexus query "<symptom>" --repo <repo> --limit 5
   ```

4. Pick likely suspect symbols from results.
5. Inspect each suspect:

   ```bash
   npx gitnexus context "<symbol>" --repo <repo>
   ```

6. Read the source files returned by GitNexus.
7. If recent edits matter, run:

   ```bash
   npx gitnexus detect-changes --scope all --repo <repo>
   ```

8. Form a root-cause hypothesis and verify with tests, logs, or targeted source inspection.

## How to Interpret Output

- `query`: look for processes and symbols related to the symptom.
- `context`: look for incoming callers, outgoing calls, process participation, and file path.
- `detect-changes`: look for changed symbols and affected execution flows.
- `cypher`: use only for focused read-only traces when standard commands are not enough.

## Useful Cypher Patterns

Direct callers:

```cypher
MATCH (caller)-[:CodeRelation {type: 'CALLS'}]->(target {name: "targetName"})
RETURN caller.name, caller.filePath
LIMIT 50
```

Short call chains into target:

```cypher
MATCH path = (a)-[:CodeRelation {type: 'CALLS'}*1..3]->(b {name: "targetName"})
RETURN [n IN nodes(path) | n.name] AS chain
LIMIT 20
```

## Output Guidance

Return:

```markdown
Root-cause hypothesis:
- ...

Evidence:
- `file` / symbol / caller chain

Likely fix area:
- ...

Validation:
- tests/commands to run

Uncertainty:
- stale index, ambiguous symbols, dynamic refs, skipped files
```

## Safety Rules

- Do not modify code until the root-cause hypothesis is grounded in source files.
- If index is stale, refresh before relying on graph results.
- Static graph analysis may miss dynamic dispatch, reflection, generated code, dependency injection, and string-based wiring.
- Use read-only Cypher only.
