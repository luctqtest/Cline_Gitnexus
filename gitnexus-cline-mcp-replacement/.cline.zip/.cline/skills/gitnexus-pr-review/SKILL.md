---
name: gitnexus-pr-review
description: Use when Cline needs to review a pull request, branch diff, or local changes, assess merge risk, find missing caller updates, and identify affected flows/tests using GitNexus CLI without MCP.
---

# GitNexus: PR Review for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks to review a PR or branch.
- The user asks if a change is safe to merge.
- The user asks what a diff affects.
- The user wants missing tests/callers identified.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

## Commands

```bash
# Inspect local branch diff
git diff main...HEAD

# Map diff to changed symbols and affected flows
npx gitnexus detect-changes --scope compare --base-ref main --repo <repo>

# Review staged/all local changes
npx gitnexus detect-changes --scope staged --repo <repo>
npx gitnexus detect-changes --scope all --repo <repo>

# Blast radius for important changed symbols
npx gitnexus impact "<changedSymbol>" --direction upstream --include-tests --repo <repo>

# Understand changed symbol role
npx gitnexus context "<changedSymbol>" --repo <repo>
```

If GitHub CLI is available:

```bash
gh pr diff <number>
gh pr view <number> --json title,author,baseRefName,headRefName,files
```

## Workflow

1. Check index status.
2. Inspect the raw diff.
3. Run `detect-changes` against the base branch.
4. For each non-trivial changed symbol, run upstream impact.
5. Use `context` on key symbols to understand caller/callee expectations.
6. Check whether direct callers are updated in the diff.
7. Check whether relevant tests are changed or exist.
8. Write a review with findings and risk.

## Review Dimensions

| Dimension | GitNexus Evidence |
|---|---|
| Correctness | caller/callee context and source reads |
| Blast radius | impact direct/indirect dependents |
| Completeness | detect-changes affected flows |
| Tests | impact with `--include-tests` and diff inspection |
| Breaking changes | direct callers outside PR not updated |

## Output Format

```markdown
## PR Review

Risk: LOW/MEDIUM/HIGH/CRITICAL

### Summary
- N files / symbols / flows affected

### Findings
- [severity] finding with evidence

### Missing Coverage
- tests or flows not covered

### Recommendation
APPROVE / REQUEST CHANGES / NEEDS DISCUSSION
```

## Safety Rules

- Do not approve solely from graph output; read changed source files.
- If index is stale, refresh before review.
- Treat direct callers outside the diff as possible breakage.
- For API changes, use `gitnexus-api-impact` as an additional skill.
