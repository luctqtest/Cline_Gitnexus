---
name: gitnexus-group
description: Use when Cline needs multi-repo or service-group analysis, group setup/status/sync, contract registry inspection, cross-repo search, or cross-repo impact using GitNexus CLI without MCP.
---

# GitNexus: Multi-Repo Groups for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user works across multiple repositories.
- The user asks about service-to-service impact.
- The user wants to create/list/sync GitNexus groups.
- The user wants contract registry or cross-link inspection.
- The user asks what breaks across repo boundaries.

## First Check

```bash
npx gitnexus list
```

Check each relevant repo is indexed. If needed, run `npx gitnexus analyze` inside each repo.

## Commands

```bash
# Group management
npx gitnexus group create <name>
npx gitnexus group add <group> <groupPath> <registryName>
npx gitnexus group remove <group> <groupPath>
npx gitnexus group list
npx gitnexus group list <name>

# Status and sync
npx gitnexus group status <name>
npx gitnexus group sync <name> --json
npx gitnexus group sync <name> --verbose --json

# Contract registry
npx gitnexus group contracts <name> --json
npx gitnexus group contracts <name> --type <type> --json
npx gitnexus group contracts <name> --unmatched --json

# Cross-repo search / impact
npx gitnexus group query <name> "<query>" --json
npx gitnexus group impact <name> --target <symbol> --repo <groupPath> --direction upstream --json
```

Resource commands:

```bash
npx gitnexus read 'gitnexus://group/<name>/contracts'
npx gitnexus read 'gitnexus://group/<name>/status'
```

Universal group-mode commands:

```bash
npx gitnexus call query --json '{"repo":"@<group>","query":"<query>"}'
npx gitnexus call impact --json '{"repo":"@<group>/<groupPath>","target":"<symbol>","direction":"upstream"}'
npx gitnexus call context --json '{"repo":"@<group>/<groupPath>","name":"<symbol>"}'
```

## Workflow: Create and Sync Group

1. List indexed repos:

   ```bash
   npx gitnexus list
   ```

2. Create group:

   ```bash
   npx gitnexus group create <name>
   ```

3. Add repos by registry name:

   ```bash
   npx gitnexus group add <name> <groupPath> <registryName>
   ```

4. Sync contracts:

   ```bash
   npx gitnexus group sync <name> --json
   ```

5. Check status:

   ```bash
   npx gitnexus group status <name>
   ```

## Workflow: Cross-Repo Impact

1. Run group status.
2. Sync if stale.
3. Run:

   ```bash
   npx gitnexus group impact <name> --target <symbol> --repo <groupPath> --direction upstream --json
   ```

4. Inspect contracts/cross-links.
5. Report cross-repo hits and blind spots.

## Output Guidance

```markdown
Group: <name>

Status:
- repo/index/contract freshness

Contracts/cross-links:
- matched
- unmatched blind spots

Impact/query results:
- local hits
- cross-repo hits

Recommended actions:
- reindex/sync/test owners
```

## Safety Rules

- Run `group status` before relying on cross-repo results.
- Run `group sync` after reindexing member repos or editing group config.
- Treat unmatched contracts as blind spots.
- Cross-repo analysis depends on all member repos being indexed and fresh.
