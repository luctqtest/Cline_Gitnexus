---
name: gitnexus-tool-map
description: Use when Cline needs to find MCP/RPC/internal tool definitions and handlers in an indexed codebase, understand tool schemas, or assess impact of tool API changes using GitNexus CLI without MCP.
---

# GitNexus: Tool Map for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks what tools a codebase exposes.
- The user asks where a specific MCP/RPC/internal tool is implemented.
- The user wants to change a tool schema/signature.
- The user wants impact analysis for tool handler changes.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

## Commands

Use `gitnexus call` for these MCP-parity tools:

```bash
# List all detected tools
npx gitnexus call tool_map --json '{"repo":"<repo>"}'

# Filter to one tool
npx gitnexus call tool_map --json '{"tool":"<toolName>","repo":"<repo>"}'
```

Fallback if a tool is not detected:

```bash
npx gitnexus query "tool <toolName> handler definition schema" --repo <repo> --limit 10
npx gitnexus context "<toolName>" --repo <repo>
```

Supporting analysis:

```bash
npx gitnexus context "<toolName>" --repo <repo>
npx gitnexus impact "<toolName>" --direction upstream --repo <repo>
```

## Workflow

1. Check index.
2. Run `tool_map` for all tools or one requested tool.
3. Identify definition file and handler file.
4. Use `context` on handler symbol.
5. Before schema/signature changes, run upstream `impact`.
6. Read definition and handler source files.
7. Summarize tool API, handler path, and change risk.

## Output Guidance

```markdown
Tool: <name>

Definition:
- file/symbol

Handler:
- file/symbol

Inputs/description:
- ...

Impact if changed:
- callers / flows / tests

Notes:
- ambiguity / stale index / dynamic registration
```

## Safety Rules

- Tool schemas may be consumed externally; treat signature changes as public API changes.
- Static detection may miss dynamic registration patterns.
- Verify definitions and handlers by reading source files.
