---
name: gitnexus-cypher
description: Use when Cline needs advanced read-only graph queries that cannot be answered by query/context/impact, including custom caller, process, route, class, and relation queries using GitNexus CLI without MCP.
---

# GitNexus: Cypher Graph Queries for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- `query`, `context`, and `impact` are not precise enough.
- The user asks for custom graph relationships.
- The user wants all callers, methods, routes, processes, or relation patterns.
- You need schema-driven exploration.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

## Commands

```bash
# Read schema when resource reader exists
npx gitnexus read 'gitnexus://repo/<repo>/schema'

# Run raw Cypher
npx gitnexus cypher '<query>' --repo <repo>

# Universal equivalent
npx gitnexus call cypher --json '{"query":"<query>","repo":"<repo>"}'
```

If schema resource output is insufficient, use known schema basics:

- Nodes: File, Folder, Function, Class, Interface, Method, CodeElement, Community, Process, Route, Tool, Property, Constructor, Struct, Enum, Trait, Impl.
- Relations use `CodeRelation` with a `type` property.
- Common relation types: CALLS, IMPORTS, EXTENDS, IMPLEMENTS, HAS_METHOD, HAS_PROPERTY, ACCESSES, MEMBER_OF, STEP_IN_PROCESS, HANDLES_ROUTE, FETCHES, HANDLES_TOOL, ENTRY_POINT_OF.

## Workflow

1. Check index.
2. Read schema if possible.
3. Start with a narrow query and `LIMIT`.
4. Run Cypher.
5. Use returned symbols with `context` or source file reads.
6. Summarize results; do not dump huge tables unless asked.

## Query Templates

Direct callers:

```cypher
MATCH (caller)-[:CodeRelation {type: 'CALLS'}]->(target {name: "targetName"})
RETURN caller.name, caller.filePath
LIMIT 50
```

Methods of a class:

```cypher
MATCH (c:Class {name: "ClassName"})-[:CodeRelation {type: 'HAS_METHOD'}]->(m:Method)
RETURN m.name, m.filePath, m.startLine
ORDER BY m.name
LIMIT 100
```

Process steps:

```cypher
MATCH (s)-[r:CodeRelation {type: 'STEP_IN_PROCESS'}]->(p:Process)
WHERE p.heuristicLabel = "ProcessName"
RETURN s.name, s.filePath, r.step
ORDER BY r.step
LIMIT 100
```

Route handlers:

```cypher
MATCH (h)-[:CodeRelation {type: 'HANDLES_ROUTE'}]->(r:Route)
RETURN r.path, h.name, h.filePath
LIMIT 100
```

Field reads/writes:

```cypher
MATCH (f)-[r:CodeRelation {type: 'ACCESSES'}]->(p:Property)
WHERE p.name = "fieldName"
RETURN f.name, f.filePath, r.reason
LIMIT 100
```

## Safety Rules

- Use read-only Cypher only.
- Always include `LIMIT` until result size is known.
- Prefer exact labels/relations from schema.
- Do not use Cypher output as final proof without source inspection.
