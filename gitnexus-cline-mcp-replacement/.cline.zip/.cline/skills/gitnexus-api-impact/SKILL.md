---
name: gitnexus-api-impact
description: Use when Cline needs to analyze API route handlers, API consumers, response shape drift, route maps, middleware, or pre-change API risk using GitNexus CLI without MCP.
---

# GitNexus: API Impact for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user wants to change an API route handler.
- The user asks which clients/components consume an endpoint.
- The user asks whether response shape changes are safe.
- The user asks for route-to-handler mapping.
- The user asks about orphaned routes or mismatched consumer fields.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

## Commands

Use `gitnexus call` for these MCP-parity tools:

```bash
# Preferred: combined route, consumer, shape, and impact report
npx gitnexus call api_impact --json '{"route":"<route>","repo":"<repo>"}'
npx gitnexus call api_impact --json '{"file":"<handlerFile>","repo":"<repo>"}'

# Route handlers and consumers
npx gitnexus call route_map --json '{"route":"<route>","repo":"<repo>"}'
npx gitnexus call route_map --json '{"repo":"<repo>"}'

# Response shape vs consumer property access
npx gitnexus call shape_check --json '{"route":"<route>","repo":"<repo>"}'
npx gitnexus call shape_check --json '{"repo":"<repo>"}'
```

Fallback exploration if a route/tool is not detected:

```bash
npx gitnexus query "<route or endpoint>" --repo <repo> --limit 10
npx gitnexus context "<handlerSymbol>" --repo <repo>
npx gitnexus impact "<handlerSymbol>" --direction upstream --repo <repo>
```

## Workflow

1. Identify route path or handler file.
2. Run `api_impact` first when available.
3. Use `route_map` for detailed route/handler/consumer mapping.
4. Use `shape_check` for response shape drift.
5. Read handler and consumer files.
6. If handler symbol is known, run `impact` for deeper blast radius.
7. Report consumers, fields accessed, mismatches, middleware, and risk.

## Risk Heuristics

| Signal | Risk |
|---|---|
| 0-3 consumers, no mismatch | LOW |
| 4-9 consumers or low-confidence attribution | MEDIUM |
| 10+ consumers or any response mismatch | HIGH |
| Auth/security/payment/data route | CRITICAL |

## Output Guidance

```markdown
API Impact: <route or file>

Risk: LOW/MEDIUM/HIGH/CRITICAL

Handlers/middleware:
- ...

Consumers:
- ...

Response shape / mismatches:
- ...

Recommended changes/tests:
- ...

Uncertainty:
- low confidence attribution / stale index / dynamic routes
```

## Safety Rules

- API response shape changes can silently break consumers; inspect consumer files.
- Low-confidence consumer attribution means a file may fetch multiple routes.
- Static analysis may miss dynamic URL construction.
- Do not change public API contract without migration/versioning consideration.
