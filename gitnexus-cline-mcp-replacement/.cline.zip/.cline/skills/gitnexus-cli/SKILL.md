---
name: gitnexus-cli
description: Use when Cline needs to setup, index, reindex, check status, list indexed repositories, run doctor, clean GitNexus indexes, or generate a wiki/docs through GitNexus CLI without MCP.
---

# GitNexus: CLI Operations for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks to index or reindex a repository.
- The user asks whether GitNexus is ready for the current repo.
- The user asks to list indexed repositories.
- A GitNexus command reports no index, stale index, or missing repository.
- The user wants to generate a GitNexus wiki/docs.
- The index seems corrupt and needs maintenance.

## First Check

Run from the target repository root:

```bash
npx gitnexus status
```

If GitNexus reports no index or stale index, run:

```bash
npx gitnexus analyze
```

If the user explicitly wants a full rebuild, run:

```bash
npx gitnexus analyze --force
```

## Core Commands

```bash
# Check current repo index status
npx gitnexus status

# Build or refresh the index
npx gitnexus analyze

# Force a full rebuild
npx gitnexus analyze --force

# Enable semantic embeddings during analysis when quality matters more than speed
npx gitnexus analyze --embeddings

# Generate repo/community skills during analysis
npx gitnexus analyze --skills

# Preserve custom AGENTS.md / CLAUDE.md GitNexus section edits
npx gitnexus analyze --skip-agents-md

# List all indexed repositories
npx gitnexus list

# Check runtime/platform/embedding capabilities
npx gitnexus doctor

# Generate wiki/docs from the graph
npx gitnexus wiki
```

## MCP-Parity Commands

Use these to inspect resources without MCP:

```bash
npx gitnexus read 'gitnexus://repos'
npx gitnexus read 'gitnexus://setup'
npx gitnexus read 'gitnexus://repo/<repo>/context'
npx gitnexus call list_repos --json '{}'
```

If a resource-specific command returns an error, fall back to:

```bash
npx gitnexus list
npx gitnexus status
```

## Workflow: Prepare GitNexus for a Repo

1. Confirm you are in the target repo root.
2. Run:

   ```bash
   npx gitnexus status
   ```

3. If no valid index exists, run:

   ```bash
   npx gitnexus analyze
   ```

4. If semantic search is important and the environment allows it, consider:

   ```bash
   npx gitnexus analyze --embeddings
   ```

5. Verify indexed repos:

   ```bash
   npx gitnexus list
   ```

6. Continue with the task-specific GitNexus skill.

## Workflow: Refresh a Stale Index

1. Run:

   ```bash
   npx gitnexus status
   ```

2. If stale, run:

   ```bash
   npx gitnexus analyze
   ```

3. If the stale state persists or the index seems corrupt, ask before using a destructive maintenance command. Then use one of:

   ```bash
   npx gitnexus analyze --force
   npx gitnexus clean --force
   npx gitnexus analyze
   ```

## Workflow: Generate Wiki

1. Confirm user wants LLM-generated documentation.
2. Check whether the environment allows external LLM calls.
3. Run:

   ```bash
   npx gitnexus wiki
   ```

4. If user requests a custom provider/model/base URL, pass the requested flags explicitly.

## How to Interpret Output

- `status` says no index: run `npx gitnexus analyze`.
- `status` says stale: run `npx gitnexus analyze` before relying on graph results.
- `list` shows multiple repos: later commands may need `--repo <name>`.
- `doctor` reports missing optional parser/platform capability: mention that some language/embedding features may be unavailable.
- `analyze` completes with skipped files/parser warnings: mention possible blind spots if relevant to the task.

## Safety Rules

- Do not run `npx gitnexus clean --all --force` unless the user explicitly asks to delete all indexes.
- Use `npx gitnexus analyze --force` only when a normal refresh is insufficient or the user asks for a full rebuild.
- `wiki` may use external LLM provider configuration; confirm this is allowed in restricted/corporate environments.
- `analyze --embeddings` may use local or configured remote embeddings; check environment restrictions if external calls are not allowed.
- GitNexus indexes source relationships, but final answers should still be confirmed by reading source files when making implementation decisions.

## Example

User asks: "Index this repo for Cline without MCP."

Run:

```bash
npx gitnexus status
npx gitnexus analyze
npx gitnexus list
```

Answer with:

- Whether indexing succeeded.
- Repo name shown by `list`.
- Any stale/skipped/parser warnings.
- Which next GitNexus skill to use for the user's actual task.
