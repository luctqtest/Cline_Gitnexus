---
name: gitnexus-impact-analysis
description: Use when Cline needs blast-radius analysis, wants to know what breaks if a symbol/file/API changes, assess risk before editing, or map current git changes to affected flows using GitNexus CLI without MCP.
---

# GitNexus: Impact Analysis for Cline

Use GitNexus through local CLI commands. Do not use MCP for this workflow.

## Use When

- The user asks "what breaks if I change X?"
- The user asks what depends on a function/class/module.
- The user wants risk assessment before editing code.
- The user wants impact of staged/unstaged changes.
- The user wants test coverage hints for a changed symbol.

## First Check

```bash
npx gitnexus status
```

If missing or stale:

```bash
npx gitnexus analyze
```

## Commands

```bash
# What depends on this? Most common pre-change check.
npx gitnexus impact "<symbol>" --direction upstream --depth 3 --repo <repo>

# What does this use?
npx gitnexus impact "<symbol>" --direction downstream --depth 2 --repo <repo>

# Include tests in traversal when checking coverage/risk
npx gitnexus impact "<symbol>" --direction upstream --include-tests --repo <repo>

# Current working tree impact
npx gitnexus detect-changes --scope unstaged --repo <repo>
npx gitnexus detect-changes --scope staged --repo <repo>
npx gitnexus detect-changes --scope all --repo <repo>

# Compare branch/PR impact
npx gitnexus detect-changes --scope compare --base-ref main --repo <repo>
```

Advanced command:

```bash
npx gitnexus call impact --json '{"target":"<symbol>","direction":"upstream","maxDepth":3,"includeTests":true,"repo":"<repo>"}'
```

## Workflow: Before Changing a Symbol

1. Check index.
2. Run upstream impact:

   ```bash
   npx gitnexus impact "<symbol>" --direction upstream --depth 3 --repo <repo>
   ```

3. Review direct dependents first.
4. Review affected processes/modules.
5. If tests matter, rerun with `--include-tests`.
6. Read source files for high-risk callers.
7. Report risk and suggested tests.

## Workflow: After Local Edits

```bash
npx gitnexus detect-changes --scope all --repo <repo>
```

Then summarize:

- changed symbols
- affected processes
- risk level
- tests to run

## Risk Heuristics

| Signal | Risk |
|---|---|
| 0-4 affected symbols, no critical flow | LOW |
| 5-15 affected symbols or 2-5 processes | MEDIUM |
| >15 symbols, many modules, or many processes | HIGH |
| Auth, payment, security, data integrity, migrations | CRITICAL |
| Direct callers outside intended change area | Potential breakage |

## Output Guidance

```markdown
Risk: LOW/MEDIUM/HIGH/CRITICAL

Direct dependents:
- ...

Affected flows/modules:
- ...

Tests to run:
- ...

Notes:
- stale index / ambiguity / dynamic references / skipped files
```

## Safety Rules

- Do not claim safety from graph results alone; read important source files.
- Refresh stale index before relying on impact.
- Dynamic/string/reflection-based references may be missed.
- For API routes, use `gitnexus-api-impact` instead or in addition.
